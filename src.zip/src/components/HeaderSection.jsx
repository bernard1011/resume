import Menu from "./ui/Menu";
import Photo from "../assets/images/photo.jpg";
import NeonButton from "./ui/NeonButton";
import { motion } from "framer-motion";

const HeaderSection = () => {
  return (
    <>
      <Menu />

      <section
        className="relative flex flex-col"
        style={{ minHeight: "100svh" }}
      >
        <div className="flex-1 mt-16 md:mt-24 flex flex-col items-center md:flex-row md:items-center md:gap-16 relative">
          <div
            className="absolute -top-10 left-1/2 -translate-x-1/2 md:left-0 md:translate-x-0 w-72 h-72 md:w-80 md:h-80 rounded-full pointer-events-none"
            style={{
              background:
                "radial-gradient(circle, rgba(0, 0, 0, 0.4) 0%, transparent 70%)",
              filter: "blur(30px)",
              zIndex: 0,
            }}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="relative z-10 flex-shrink-0"
          >
            <div
              className="relative rounded-full overflow-hidden"
              style={{
                width: "clamp(180px, 30vw, 240px)",
                height: "clamp(180px, 30vw, 240px)",
                border: "3px solid transparent",
                background:
                  "linear-gradient(#0a0a0a, #0a0a0a) padding-box, conic-gradient(from 180deg, #2a2a2a, #1a1a1a, #3a3a3a, #2a2a2a) border-box",
                borderRadius: "9999px",
                boxShadow: "0 0 30px rgba(0,0,0,0.5)",
              }}
            >
              <img
                src={Photo}
                alt="Danya — Frontend Developer"
                className="w-full h-full object-cover object-top"
                style={{ borderRadius: "9999px" }}
              />
            </div>
          </motion.div>

          <div className="relative z-10 text-center md:text-left flex flex-col gap-4 mt-6 md:mt-0">
            <motion.div
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="inline-flex items-center gap-2 self-center md:self-start"
            >
              <span
                className="text-xs font-semibold tracking-widest uppercase px-3 py-1 rounded-full"
                style={{
                  background: "rgba(0, 0, 0, 0.25)",
                  border: "1px solid rgba(255,255,255,0.15)",
                  color: "rgba(255,255,255,0.85)",
                  letterSpacing: "0.15em",
                }}
              >
                ✦ Available for work
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.25 }}
              className="font-bold text-white"
              style={{
                fontSize: "clamp(2rem, 5vw, 3.5rem)",
                lineHeight: 1.1,
                letterSpacing: "-0.02em",
              }}
            >
              Hello! 👋
              <span
                className="block mt-1"
                style={{
                  background:
                    "linear-gradient(90deg, #fff 0%, #e0e0e0 60%, #c0c0c0 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                My name is Danya
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-base md:text-lg leading-relaxed max-w-md"
              style={{ color: "rgba(209,213,219,0.85)" }}
            >
              I am a{" "}
              <span
                style={{ color: "rgba(255,255,255,0.85)", fontWeight: 600 }}
              >
                Frontend Developer
              </span>{" "}
              from Ukraine who is passionate about web technologies and
              continuous learning.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.55 }}
              className="flex gap-3 mt-2 justify-center md:justify-start flex-wrap"
            >
              <NeonButton variant="primary" size="md" href="#projects">
                View Projects
              </NeonButton>
              <NeonButton variant="secondary" size="md" href="#contact">
                Contact Me
              </NeonButton>
            </motion.div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.5 }}
          className="w-full flex justify-center pb-8"
        >
          <svg
            className="arrows-animate"
            width="28"
            height="32"
            viewBox="0 0 28 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            style={{ overflow: "visible" }}
          >
            <path
              d="M2 2L14 13L26 2"
              stroke="rgba(0,0,0,0.6)"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M2 14L14 25L26 14"
              stroke="rgba(0,0,0,0.6)"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.6"
            />
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </svg>
        </motion.div>
      </section>
    </>
  );
};

export default HeaderSection;
